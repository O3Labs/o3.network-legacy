# what-the-coin
Chrome Extension
https://chrome.google.com/webstore/detail/what-the-coin/jmnkipolekpoakniepbakodfgjcneoko

![usage](https://d26dzxoao6i3hh.cloudfront.net/items/182b432a2K1i1j1I0t2S/Screen%20Recording%202017-12-05%20at%2005.09%20PM.gif?v=76ae8f6b)
